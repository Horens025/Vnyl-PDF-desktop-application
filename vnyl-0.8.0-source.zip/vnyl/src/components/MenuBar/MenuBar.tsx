import { useEffect, useLayoutEffect, useRef, useState } from 'react';

import { announce } from '@/a11y/announcer';
import { commandRegistry } from '@/commands';
import { Icon, IconButton, type IconName } from '@/components/common';
import { useImageEditStore } from '@/features/imageedit';
import { usePageOpsStore } from '@/features/pageops';
import { useSplitStore } from '@/features/split';
import { useTextEditStore } from '@/features/textedit';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import { useContributionStore } from '@/plugins';
import { isTauri } from '@/core/document/openDocument';
import { originalDocumentUrl } from '@/core/document/openFromQuery';
import { ocrAvailable } from '@/features/ocr';
import { useDocumentMutationStore } from '@/state/documentMutationStore';
import { useDocumentStore } from '@/state/documentStore';
import { useViewerStore } from '@/state/viewerStore';
import { NARROW_VIEWPORT_QUERY } from '@/theme/breakpoints';
import {
  DARK_SCHEME_LABELS,
  DARK_SCHEME_TINT,
  THEME_LABELS,
  useThemeStore,
  type DarkScheme,
  type UiTheme,
} from '@/theme/themeStore';

/* ---------------------------------------------------------------------------
 * Menu model
 *
 * The bar is data-driven: each top-level entry is a label plus a flat list of
 * rows, and the same list feeds both the desktop menu bar (one dropdown per
 * top-level label) and the narrow-viewport hamburger (all of them flattened
 * into one scrollable dropdown, grouped by heading). Everything executes
 * through the command registry, exactly like the toolbar buttons do.
 * ------------------------------------------------------------------------- */

type MenuItemRole = 'menuitemcheckbox' | 'menuitemradio';

interface MenuItemDef {
  kind: 'item';
  /** Stable key; the owning command id where one exists. */
  id: string;
  label: string;
  icon?: IconName;
  /** Renders the dark-scheme color swatch instead of `icon` (Night/Green/Amber). */
  swatch?: DarkScheme;
  /** Omitted for a plain menuitem; set for the checkable rows. */
  role?: MenuItemRole;
  checked?: boolean;
  disabled?: boolean;
  shortcut?: string;
  /** Preserve the page text selection on click (Comment / Highlight need it). */
  preserveSelection?: boolean;
  onSelect: () => void;
}

interface MenuSeparatorDef {
  kind: 'separator';
  id: string;
}

type MenuEntryDef = MenuItemDef | MenuSeparatorDef;

interface TopMenuDef {
  id: string;
  label: string;
  entries: MenuEntryDef[];
}

const DARK_SCHEMES: DarkScheme[] = ['night', 'green', 'amber'];

const run = (id: string) => commandRegistry.execute(id);

/** The dark-scheme swatch's ink color, derived from the same tint table the
    renderer and AppearanceMenu use so the app's two scheme pickers can never
    drift apart. Night has no tint and shows plain white ink. */
function inkColor(scheme: DarkScheme): string {
  const tint = DARK_SCHEME_TINT[scheme];
  return tint ? `rgb(${tint[0]}, ${tint[1]}, ${tint[2]})` : '#ffffff';
}

/** Render a declared "Mod+Shift+X" binding the way the toolbar's own tooltips
    already do, e.g. "Ctrl/Cmd + Shift + S". */
function formatShortcut(keybinding: string | undefined): string | undefined {
  if (!keybinding) return undefined;
  return keybinding
    .split('+')
    .map((part) => {
      if (part === 'Mod') return 'Ctrl/Cmd';
      if (part === 'Shift' || part === 'Alt') return part;
      return part.length === 1 ? part.toUpperCase() : part;
    })
    .join(' + ');
}

/** A command's own shortcut label, if it declares one. Sourced from the
    registry rather than hand-typed, so the menu never drifts from the actual
    binding a command declares. */
function shortcutFor(commandId: string): string | undefined {
  return formatShortcut(commandRegistry.get(commandId)?.keybinding);
}

/** Whether a command can run right now: its own guard if it declares one,
    mirroring the check commandRegistry.execute performs before running it.
    Every row goes through this. Disabling on `hasDoc` alone (which the
    document-backed rows used to do) left Save, Print, and OCR enabled while
    the cross-feature mutation lock was held, so the menu bar and the toolbar
    disagreed about the very same command. */
function commandEnabled(commandId: string): boolean {
  const command = commandRegistry.get(commandId);
  return !command?.when || command.when();
}

/** itemRefs key for one row: the owning menu plus its index within that menu. */
const itemKey = (menuId: string, entryIndex: number) => `${menuId}:${entryIndex}`;

function firstEnabledIndex(entries: MenuEntryDef[]): number {
  return entries.findIndex((e) => e.kind === 'item' && !e.disabled);
}

function lastEnabledIndex(entries: MenuEntryDef[]): number {
  for (let i = entries.length - 1; i >= 0; i--) {
    const e = entries[i];
    if (e.kind === 'item' && !e.disabled) return i;
  }
  return -1;
}

/** Next focusable row from `from` in `dir` (1 or -1), wrapping, skipping
    separators and disabled items. -1 if nothing in the menu can take focus. */
function stepEnabledIndex(entries: MenuEntryDef[], from: number, dir: 1 | -1): number {
  const n = entries.length;
  for (let step = 1; step <= n; step++) {
    const idx = (((from + dir * step) % n) + n) % n;
    const e = entries[idx];
    if (e.kind === 'item' && !e.disabled) return idx;
  }
  return -1;
}

/** The application menu bar: File / Edit / View / Annotate / Sign / Tools /
    Help, rendered above the toolbar. Pure DOM (no native menus), so it works
    identically in the Tauri shell, the browser build, and the VS Code webview. */
export function MenuBar() {
  const hasDoc = useDocumentStore((s) => s.status === 'ready');
  const sidebarOpen = useViewerStore((s) => s.sidebarOpen);
  const splitOpen = useSplitStore((s) => s.open);
  const handMode = useViewerStore((s) => s.handMode);
  const autoScroll = useViewerStore((s) => s.autoScroll);
  const theme = useThemeStore((s) => s.theme);
  const resolvedTheme = useThemeStore((s) => s.resolvedTheme);
  const darkScheme = useThemeStore((s) => s.darkScheme);
  const setTheme = useThemeStore((s) => s.setTheme);
  const setDarkScheme = useThemeStore((s) => s.setDarkScheme);
  const toolbarItems = useContributionStore((s) => s.toolbarItems);
  // The two in-place editing tools are toggles, so their menu rows carry live
  // checked state the same way the View menu's do.
  const textEditActive = useTextEditStore((s) => s.active);
  const imageEditActive = useImageEditStore((s) => s.active);
  // Not read directly below: the Pages rows are enabled by their commands'
  // guards, and those consult a selection this component would otherwise never
  // hear about, leaving the menu showing a stale disabled state.
  usePageOpsStore((s) => s.selection.size);
  usePageOpsStore((s) => s.undoStack.length);
  // Same again for the cross-feature mutation lock, which File's and Edit's
  // rows now follow through their commands' guards.
  useDocumentMutationStore((s) => s.active.length);
  const isMobile = useMediaQuery(NARROW_VIEWPORT_QUERY);

  // A row backed by a command that requires an open document, e.g. Save. The
  // command's own guard as well as `hasDoc`: several of them (Save, Save a
  // copy, Print, OCR) also refuse while the cross-feature mutation lock is
  // held, and a row that stays clickable through that is exactly the
  // inconsistency the toolbar's disabled Save makes visible.
  const docItem = (commandId: string, label: string, icon: IconName): MenuItemDef => ({
    kind: 'item',
    id: commandId,
    label,
    icon,
    disabled: !hasDoc || !commandEnabled(commandId),
    shortcut: shortcutFor(commandId),
    onSelect: () => run(commandId),
  });

  // A row whose enabled state comes from the command's own guard rather than
  // just "is a document open", e.g. the page operations, which also need pages
  // to be picked out.
  const cmdItem = (commandId: string, label: string, icon: IconName): MenuItemDef => ({
    kind: 'item',
    id: commandId,
    label,
    icon,
    disabled: !commandEnabled(commandId),
    shortcut: shortcutFor(commandId),
    onSelect: () => run(commandId),
  });

  // A row backed by a command that works with no document open, e.g. Open.
  // Still guard-checked: Open and Combine both replace the document, so both
  // wait on the mutation lock even though neither needs one already open.
  const freeItem = (commandId: string, label: string, icon?: IconName): MenuItemDef => ({
    kind: 'item',
    id: commandId,
    label,
    icon,
    disabled: !commandEnabled(commandId),
    shortcut: shortcutFor(commandId),
    onSelect: () => run(commandId),
  });

  const checkItem = (
    commandId: string,
    label: string,
    icon: IconName,
    checked: boolean,
    requiresDoc: boolean,
  ): MenuItemDef => ({
    kind: 'item',
    id: commandId,
    label,
    icon,
    role: 'menuitemcheckbox',
    checked,
    disabled: requiresDoc ? !hasDoc : false,
    shortcut: shortcutFor(commandId),
    onSelect: () => run(commandId),
  });

  const sep = (id: string): MenuSeparatorDef => ({ kind: 'separator', id });

  // The Tools menu is entirely plugin-contributed (Word Count today); its
  // enabled state comes from each command's own guard rather than `hasDoc`
  // directly, since a future plugin's command may have a different guard.
  const toolsEntries: MenuItemDef[] = [
    freeItem('tools.hub', 'All tools…', 'menu'),
    freeItem('tools.compare', 'Compare documents…', 'split-columns'),
    ...toolbarItems.map((item): MenuItemDef => ({
      kind: 'item',
      id: item.id,
      label: item.title,
      icon: (item.icon as IconName) ?? 'note',
      disabled: !commandEnabled(item.commandId),
      shortcut: shortcutFor(item.commandId),
      onSelect: () => run(item.commandId),
    })),
  ];

  // Recomputed per render; `hasDoc` flipping is what brings this into view.
  // `hasDoc` also matches what `originalDocumentUrl` itself checks (the live
  // document's fingerprint), so the two cannot disagree; kept explicit rather
  // than relying on that so this reads the same way the sibling `hasDoc`
  // checks below do.
  const canDownloadOriginal = !isTauri() && hasDoc && originalDocumentUrl() !== null;

  const menus: TopMenuDef[] = [
    {
      id: 'file',
      label: 'File',
      entries: [
        freeItem('file.open', 'Open', 'folder-open'),
        freeItem('file.combine', 'Combine PDFs…', 'combine'),
        sep('file-sep-1'),
        freeItem('tabs.next', 'Next document', 'chevron-right'),
        freeItem('tabs.prev', 'Previous document', 'chevron-left'),
        sep('file-sep-tabs'),
        docItem('file.save', 'Save', 'save'),
        docItem('file.saveAs', 'Save a copy', 'download'),
        // Browser build only, and only when the document came from a URL: the
        // extension redirects PDF navigations here, including ones the site
        // meant as a download, so the untouched file stays one click away.
        ...(canDownloadOriginal
          ? [freeItem('file.downloadOriginal', 'Download original', 'download')]
          : []),
        sep('file-sep-2'),
        docItem('file.print', 'Print…', 'print'),
      ],
    },
    {
      id: 'edit',
      label: 'Edit',
      entries: [
        // The two in-place tools (editing content the PDF already has) sit
        // above the separator with the additive ones below, so "Edit text" and
        // "Edit images" read as a pair rather than "Edit images" looking like a
        // variant of "Add image".
        checkItem('textedit.toggle', 'Edit text', 'pencil', textEditActive, true),
        checkItem('imageedit.toggle', 'Edit images', 'crop', imageEditActive, true),
        sep('edit-sep-1'),
        docItem('edit.addText', 'Add text box', 'type'),
        docItem('edit.addImage', 'Add image', 'image'),
        docItem('edit.addCheckmark', 'Add check mark', 'check'),
        // Absent, not disabled, in builds without the OCR runtime: the Chrome
        // extension package leaves it out entirely.
        ...(ocrAvailable()
          ? [docItem('ocr.recognizeDocument', 'Recognize text (OCR)', 'scan')]
          : []),
        sep('edit-sep-2'),
        docItem('search.toggle', 'Find', 'search'),
      ],
    },
    {
      id: 'pages',
      label: 'Pages',
      // These rows follow their commands' own guards rather than `hasDoc`:
      // everything below "Organize pages" needs a selection as well as a
      // document, and `commandEnabled` is what knows that.
      entries: [
        docItem('pageops.organize', 'Organize pages…', 'list'),
        sep('pages-sep-1'),
        cmdItem('pageops.moveUp', 'Move pages up', 'chevron-up'),
        cmdItem('pageops.moveDown', 'Move pages down', 'chevron-down'),
        sep('pages-sep-2'),
        cmdItem('pageops.rotateLeft', 'Rotate pages left', 'rotate-left'),
        cmdItem('pageops.rotateRight', 'Rotate pages right', 'rotate-right'),
        sep('pages-sep-3'),
        cmdItem('pageops.delete', 'Delete pages', 'trash'),
        cmdItem('pageops.undo', 'Undo page change', 'undo'),
      ],
    },
    {
      id: 'view',
      label: 'View',
      entries: [
        docItem('view.zoomIn', 'Zoom in', 'zoom-in'),
        docItem('view.zoomOut', 'Zoom out', 'zoom-out'),
        sep('view-sep-1'),
        docItem('view.fitWidth', 'Fit width', 'fit-width'),
        docItem('view.fitPage', 'Fit page', 'fit-page'),
        sep('view-sep-2'),
        checkItem('view.toggleHandMode', 'Hand tool', 'hand', handMode, true),
        checkItem('view.toggleAutoScroll', 'Auto-scroll', 'auto-scroll', autoScroll, true),
        sep('view-sep-3'),
        checkItem('view.toggleSidebar', 'Sidebar', 'sidebar', sidebarOpen, false),
        checkItem('view.toggleSplit', 'Split view', 'split-columns', splitOpen, false),
        sep('view-sep-4'),
        {
          kind: 'item',
          id: 'theme.toggle',
          label: 'Toggle light / dark',
          icon: resolvedTheme === 'dark' ? 'sun' : 'moon',
          shortcut: shortcutFor('theme.toggle'),
          onSelect: () => run('theme.toggle'),
        },
        {
          // The toggle above only alternates light and dark, so without this
          // row the third mode is unreachable from the one surface that
          // implements the full menu keyboard pattern. Checking it hands the
          // choice back to the OS; unchecking it pins the theme resolved at
          // that moment, which is what the user is looking at.
          kind: 'item',
          id: 'view.matchSystem',
          label: 'Match system',
          icon: 'contrast',
          role: 'menuitemcheckbox',
          checked: theme === 'system',
          onSelect: () => {
            const next: UiTheme = theme === 'system' ? resolvedTheme : 'system';
            setTheme(next);
            announce(`Viewing mode ${THEME_LABELS[next]}`);
          },
        },
        sep('view-sep-5'),
        ...DARK_SCHEMES.map((scheme): MenuItemDef => ({
          kind: 'item',
          id: `view.darkScheme.${scheme}`,
          label: DARK_SCHEME_LABELS[scheme],
          swatch: scheme,
          role: 'menuitemradio',
          checked: darkScheme === scheme,
          onSelect: () => {
            setDarkScheme(scheme);
            // The row's new checked state lands behind the dropdown as it
            // closes, so this is the only feedback the change gets. Same
            // sentence the appearance menu says, since it is the same change.
            announce(`Dark reading color ${DARK_SCHEME_LABELS[scheme]}`);
          },
        })),
      ],
    },
    {
      id: 'annotate',
      label: 'Annotate',
      entries: [
        // Both read the live text selection on click; see the mousedown
        // preventDefault on menu items and triggers below, without which the
        // click that reaches them would collapse the selection first.
        { ...docItem('annotate.addNote', 'Add comment', 'comment'), preserveSelection: true },
        docItem('annotate.toolbar', 'Markup toolbar', 'highlighter'),
        { ...docItem('annotate.highlight', 'Highlight', 'highlighter'), preserveSelection: true },
        { ...docItem('annotate.underline', 'Underline', 'underline'), preserveSelection: true },
        {
          ...docItem('annotate.strikeout', 'Strikethrough', 'strikethrough'),
          preserveSelection: true,
        },
        {
          ...docItem('annotate.squiggly', 'Squiggly underline', 'squiggly'),
          preserveSelection: true,
        },
      ],
    },
    {
      id: 'sign',
      label: 'Sign',
      entries: [
        docItem('sign.addSignature', 'Add signature', 'signature'),
        docItem('sign.digitallySign', 'Digitally sign', 'shield'),
      ],
    },
    // Hidden entirely rather than shown empty: with no plugin contributing a
    // toolbar item there is nothing for it to hold.
    ...(toolsEntries.length > 0 ? [{ id: 'tools', label: 'Tools', entries: toolsEntries }] : []),
    {
      id: 'help',
      label: 'Help',
      entries: [
        freeItem('help.shortcuts', 'Keyboard shortcuts', 'list'),
        freeItem('help.about', 'About Vnyl', 'info'),
        // Desktop only: the browser build has no Tauri shell to update.
        ...(isTauri() ? [freeItem('help.checkForUpdates', 'Check for updates')] : []),
      ],
    },
  ];

  /* -------------------------------------------------------------------------
   * Desktop: ARIA APG menu bar pattern (menubar / menuitem, roving tabindex).
   * ---------------------------------------------------------------------- */

  const [openId, setOpenId] = useState<string | null>(null);
  const [activeId, setActiveId] = useState<string>('file');
  const [mobileOpen, setMobileOpen] = useState(false);

  const barRef = useRef<HTMLDivElement>(null);
  const triggerRefs = useRef(new Map<string, HTMLButtonElement>());
  // Keyed by owning menu + row index, not a bare index into a shared array:
  // only one menu is open at a time, so a flat array happens to work today,
  // but it silently relies on that and on the index helpers never returning a
  // separator's slot (which no ref ever fills). Keying by menu makes a stale
  // row from a previously-open, longer menu unreachable by construction.
  const itemRefs = useRef(new Map<string, HTMLButtonElement>());
  // Which item to focus once the menu that is about to open has mounted (its
  // items do not exist yet on the tick that opens it).
  const pendingFocusRef = useRef<'first' | 'last' | null>(null);
  // Read inside the layout effect below without adding `menus` (a fresh array
  // every render) to its dependency list.
  const menusRef = useRef(menus);
  menusRef.current = menus;

  // Click outside the bar closes whichever menu is open.
  useEffect(() => {
    if (!openId) return;
    const onDown = (e: PointerEvent) => {
      if (barRef.current && !barRef.current.contains(e.target as Node)) setOpenId(null);
    };
    window.addEventListener('pointerdown', onDown);
    return () => window.removeEventListener('pointerdown', onDown);
  }, [openId]);

  // Once a freshly opened menu's rows exist in the DOM, apply the focus move
  // that opened it (first row for ArrowDown/Enter, last for ArrowUp).
  useLayoutEffect(() => {
    const focus = pendingFocusRef.current;
    pendingFocusRef.current = null;
    if (!openId || !focus) return;
    const menu = menusRef.current.find((m) => m.id === openId);
    if (!menu) return;
    const idx =
      focus === 'first' ? firstEnabledIndex(menu.entries) : lastEnabledIndex(menu.entries);
    focusRow(menu.id, idx);
  }, [openId]);

  // The mobile hamburger's single dropdown: same outside-click / Escape
  // handling as ToolbarOverflow's "More tools" menu.
  useEffect(() => {
    if (!mobileOpen) return;
    const onDown = (e: PointerEvent) => {
      if (barRef.current && !barRef.current.contains(e.target as Node)) setMobileOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMobileOpen(false);
    };
    window.addEventListener('pointerdown', onDown);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('pointerdown', onDown);
      window.removeEventListener('keydown', onKey);
    };
  }, [mobileOpen]);

  const focusTrigger = (id: string) => triggerRefs.current.get(id)?.focus();

  /** Focus one row of `menuId`. A -1 index (nothing enabled) is a no-op. */
  const focusRow = (menuId: string, entryIndex: number) => {
    if (entryIndex !== -1) itemRefs.current.get(itemKey(menuId, entryIndex))?.focus();
  };

  /** Open `id`'s menu and focus its first/last enabled row. If it is already
      open (focus can still be on the trigger right after a click), its rows
      already exist, so focus is applied immediately; otherwise the layout
      effect above applies it once the rows mount. */
  const openMenuAndFocus = (id: string, focus: 'first' | 'last') => {
    setActiveId(id);
    if (openId === id) {
      const menu = menus.find((m) => m.id === id);
      const idx = menu
        ? focus === 'first'
          ? firstEnabledIndex(menu.entries)
          : lastEnabledIndex(menu.entries)
        : -1;
      focusRow(id, idx);
      return;
    }
    pendingFocusRef.current = focus;
    setOpenId(id);
  };

  /** Move the roving tab stop to `id`'s trigger. If a menu was already open,
      the open menu follows the moving focus (closing the old one, opening the
      new one) while focus itself stays on the trigger row, not its items —
      the "arrow across the bar while previewing each menu" behavior. */
  const moveTrigger = (id: string) => {
    setActiveId(id);
    focusTrigger(id);
    if (openId) {
      pendingFocusRef.current = null;
      setOpenId(id);
    }
  };

  const activateEntry = (entry: MenuItemDef, triggerId: string) => {
    setOpenId(null);
    entry.onSelect();
    focusTrigger(triggerId);
  };

  const onTriggerClick = (id: string) => {
    setActiveId(id);
    // Focus is applied here explicitly because the trigger's mousedown is
    // preventDefault-ed (see below), so the browser never focuses it itself.
    focusTrigger(id);
    if (openId === id) {
      setOpenId(null);
    } else {
      pendingFocusRef.current = null;
      setOpenId(id);
    }
  };

  // While any menu is open, hovering a different trigger slides the open menu
  // across to it (click-then-slide), matching a native app menu bar.
  //
  // The open menu and the roving tab stop follow the pointer, but DOM focus
  // does not: a native menu bar moves the *highlight* on hover, not the
  // keyboard focus. Calling focusTrigger here would yank focus out from under
  // a screen-reader or keyboard user whose pointer merely passed over the bar,
  // and fire a focus/blur pair per trigger crossed. A click still focuses
  // explicitly (see onTriggerClick), which is the interaction that should.
  const onTriggerMouseEnter = (id: string) => {
    if (openId && openId !== id) {
      pendingFocusRef.current = null;
      setActiveId(id);
      setOpenId(id);
    }
  };

  const onTriggerKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>, index: number) => {
    const count = menus.length;
    const menu = menus[index];
    switch (e.key) {
      case 'ArrowRight':
        e.preventDefault();
        moveTrigger(menus[(index + 1) % count].id);
        break;
      case 'ArrowLeft':
        e.preventDefault();
        moveTrigger(menus[(index - 1 + count) % count].id);
        break;
      case 'Home':
        e.preventDefault();
        moveTrigger(menus[0].id);
        break;
      case 'End':
        e.preventDefault();
        moveTrigger(menus[count - 1].id);
        break;
      case 'ArrowDown':
        e.preventDefault();
        openMenuAndFocus(menu.id, 'first');
        break;
      case 'ArrowUp':
        e.preventDefault();
        openMenuAndFocus(menu.id, 'last');
        break;
      case 'Enter':
      case ' ':
        e.preventDefault();
        openMenuAndFocus(menu.id, 'first');
        break;
      case 'Escape':
        if (openId === menu.id) {
          e.preventDefault();
          setOpenId(null);
        }
        break;
      case 'Tab':
        if (openId) setOpenId(null);
        break;
      default:
        break;
    }
  };

  const onItemKeyDown = (
    e: React.KeyboardEvent<HTMLButtonElement>,
    menu: TopMenuDef,
    menuIndex: number,
    entryIndex: number,
  ) => {
    const { entries } = menu;
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        focusRow(menu.id, stepEnabledIndex(entries, entryIndex, 1));
        break;
      case 'ArrowUp':
        e.preventDefault();
        focusRow(menu.id, stepEnabledIndex(entries, entryIndex, -1));
        break;
      case 'Home':
        e.preventDefault();
        focusRow(menu.id, firstEnabledIndex(entries));
        break;
      case 'End':
        e.preventDefault();
        focusRow(menu.id, lastEnabledIndex(entries));
        break;
      case 'ArrowRight': {
        e.preventDefault();
        const next = menus[(menuIndex + 1) % menus.length];
        openMenuAndFocus(next.id, 'first');
        break;
      }
      case 'ArrowLeft': {
        e.preventDefault();
        const prev = menus[(menuIndex - 1 + menus.length) % menus.length];
        openMenuAndFocus(prev.id, 'first');
        break;
      }
      case 'Escape':
        e.preventDefault();
        setOpenId(null);
        focusTrigger(menu.id);
        break;
      case 'Tab':
        // Let focus leave the widget naturally; just don't leave a stray menu open.
        setOpenId(null);
        break;
      default:
        break;
    }
  };

  /**
   * Arrow / Home / End navigation for the mobile hamburger's single flat
   * dropdown. Unlike the desktop bar, whose rows are indexed per menu, this
   * one is one scrollable list of every command grouped by heading, so it
   * navigates the enabled buttons in DOM order and needs no model of its own.
   */
  const onMobileMenuKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    const step = e.key === 'ArrowDown' ? 1 : e.key === 'ArrowUp' ? -1 : 0;
    if (!step && e.key !== 'Home' && e.key !== 'End') return;

    const rows = Array.from(
      e.currentTarget.querySelectorAll<HTMLButtonElement>('button:not([disabled])'),
    );
    if (rows.length === 0) return;
    e.preventDefault();

    if (e.key === 'Home') return rows[0].focus();
    if (e.key === 'End') return rows[rows.length - 1].focus();

    // Wrapping, and starting from the top (or bottom) when focus is still on
    // the hamburger itself rather than on a row.
    const current = rows.indexOf(document.activeElement as HTMLButtonElement);
    if (current === -1) return (step === 1 ? rows[0] : rows[rows.length - 1]).focus();
    rows[(current + step + rows.length) % rows.length].focus();
  };

  const renderGlyph = (entry: MenuItemDef) => (
    <span className="folio-menubar__menuitem-icon">
      {entry.swatch ? (
        <span className="folio-swatch" style={{ color: inkColor(entry.swatch) }} aria-hidden="true">
          A
        </span>
      ) : (
        entry.icon && <Icon name={entry.icon} size={16} />
      )}
    </span>
  );

  /* -------------------------------------------------------------------------
   * Mobile (≤640px): one hamburger button, one flat dropdown grouped by menu.
   * ---------------------------------------------------------------------- */
  if (isMobile) {
    return (
      <div className="folio-menubar folio-menubar--mobile" ref={barRef}>
        <div className="folio-dropdown">
          <IconButton
            icon="menu"
            label="Menu"
            active={mobileOpen}
            aria-haspopup="menu"
            aria-expanded={mobileOpen}
            // The hamburger is the only route to Comment / Highlight on
            // narrow viewports; keep the text selection alive on the way in.
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => setMobileOpen((o) => !o)}
          />
          {mobileOpen && (
            <div
              className="folio-dropdown__menu folio-menubar__mobile-menu"
              role="menu"
              aria-label="Menu"
              // Programmatically focusable but not a tab stop, which is the
              // APG shape for a menu container and what lets it legitimately
              // own the key handler below (a listener on an element that can
              // never hold focus is the anti-pattern the lint rule is aimed
              // at, even though these events arrive by bubbling from the rows).
              tabIndex={-1}
              // role="menu" is a promise about keyboard behavior, not just a
              // label: a screen reader announces "menu" and its user reaches
              // for the arrow keys. Tab alone reaching the rows contradicts
              // that, so the whole dropdown handles arrows / Home / End once
              // here, delegating off the focused row rather than wiring a
              // handler onto every button.
              onKeyDown={onMobileMenuKeyDown}
            >
              {menus.map((menu) => (
                <div
                  key={menu.id}
                  role="group"
                  aria-label={menu.label}
                  className="folio-menubar__mobile-group"
                >
                  <div className="folio-menubar__mobile-heading" aria-hidden="true">
                    {menu.label}
                  </div>
                  {menu.entries
                    .filter((entry): entry is MenuItemDef => entry.kind === 'item')
                    .map((entry) => (
                      <button
                        key={entry.id}
                        type="button"
                        role={entry.role ?? 'menuitem'}
                        aria-checked={entry.role ? entry.checked : undefined}
                        className="folio-dropdown__item"
                        disabled={entry.disabled}
                        onMouseDown={
                          entry.preserveSelection ? (e) => e.preventDefault() : undefined
                        }
                        onClick={() => {
                          setMobileOpen(false);
                          entry.onSelect();
                        }}
                      >
                        {renderGlyph(entry)}
                        <span className="folio-dropdown__label">{entry.label}</span>
                        {entry.shortcut && (
                          <span className="folio-menubar__mobile-shortcut" aria-hidden="true">
                            {entry.shortcut}
                          </span>
                        )}
                        {entry.checked && <Icon name="check" size={16} />}
                      </button>
                    ))}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  /* -------------------------------------------------------------------------
   * Desktop: the full seven-menu bar.
   * ---------------------------------------------------------------------- */
  return (
    <div className="folio-menubar" role="menubar" aria-label="Application menu" ref={barRef}>
      {menus.map((menu, menuIndex) => {
        const isOpen = openId === menu.id;
        return (
          // role="none" because a menubar may only own menuitem /
          // menuitemcheckbox / menuitemradio / group / separator: an unroled
          // div between the bar and its triggers breaks that ownership, and
          // with it the set semantics a screen reader announces ("item 2 of
          // 7"). The wrapper exists purely to position the dropdown, so
          // removing it from the accessibility tree is exactly right.
          <div className="folio-menubar__item" role="none" key={menu.id}>
            <button
              type="button"
              role="menuitem"
              className="folio-menubar__trigger"
              aria-haspopup="menu"
              aria-expanded={isOpen}
              tabIndex={activeId === menu.id ? 0 : -1}
              ref={(el) => {
                if (el) triggerRefs.current.set(menu.id, el);
                else triggerRefs.current.delete(menu.id);
              }}
              // Like a native menu bar, opening a menu must not disturb the
              // page text selection: Annotate's Comment / Highlight act on it,
              // and a plain button mousedown would collapse it before the
              // click lands. Focus moves via onTriggerClick instead.
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => onTriggerClick(menu.id)}
              onKeyDown={(e) => onTriggerKeyDown(e, menuIndex)}
              onMouseEnter={() => onTriggerMouseEnter(menu.id)}
            >
              {menu.label}
            </button>
            {isOpen && (
              <div className="folio-menubar__menu" role="menu" aria-label={menu.label}>
                {menu.entries.map((entry, entryIndex) =>
                  entry.kind === 'separator' ? (
                    <div key={entry.id} role="separator" className="folio-menubar__sep" />
                  ) : (
                    <button
                      key={entry.id}
                      type="button"
                      role={entry.role ?? 'menuitem'}
                      aria-checked={entry.role ? entry.checked : undefined}
                      className="folio-menubar__menuitem"
                      disabled={entry.disabled}
                      ref={(el) => {
                        if (el) itemRefs.current.set(itemKey(menu.id, entryIndex), el);
                        else itemRefs.current.delete(itemKey(menu.id, entryIndex));
                      }}
                      onMouseDown={entry.preserveSelection ? (e) => e.preventDefault() : undefined}
                      onClick={() => activateEntry(entry, menu.id)}
                      onKeyDown={(e) => onItemKeyDown(e, menu, menuIndex, entryIndex)}
                    >
                      {renderGlyph(entry)}
                      <span className="folio-menubar__menuitem-label">{entry.label}</span>
                      {entry.shortcut && (
                        <span className="folio-menubar__menuitem-shortcut" aria-hidden="true">
                          {entry.shortcut}
                        </span>
                      )}
                      {entry.checked && (
                        <span className="folio-menubar__menuitem-check">
                          <Icon name="check" size={16} />
                        </span>
                      )}
                    </button>
                  ),
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
