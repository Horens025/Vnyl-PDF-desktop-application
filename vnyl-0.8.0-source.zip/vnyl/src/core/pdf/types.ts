/**
 * Engine-agnostic PDF types.
 *
 * Nothing in this file imports PDF.js. The rest of the app depends only on
 * these shapes and on {@link PdfEngine}, so the underlying renderer (PDF.js
 * today, potentially PDFium later) can be swapped without touching the UI.
 */

/** Where a document's bytes come from. */
export type DocumentSource =
  /** `path` is the on-disk origin (desktop only); present iff Save-in-place can write back. */
  | { kind: 'bytes'; data: Uint8Array; name?: string; path?: string }
  | { kind: 'url'; url: string; name?: string };

/** Summary returned right after a document loads. */
export interface PdfDocumentInfo {
  numPages: number;
  fingerprint: string;
  name: string;
}

/** Document-level metadata (from the PDF info dictionary / XMP). */
export interface PdfMetadata {
  title?: string;
  author?: string;
  subject?: string;
  keywords?: string;
  creator?: string;
  producer?: string;
  creationDate?: string;
  modificationDate?: string;
  pageCount: number;
}

/** A single entry in the document outline (bookmarks / table of contents). */
export interface OutlineNode {
  title: string;
  /** 1-based page number the entry points to, or null if it cannot resolve. */
  pageNumber: number | null;
  children: OutlineNode[];
}

/** Rendered size of a page, in CSS pixels, at a given scale. */
export interface PageDimensions {
  width: number;
  height: number;
}

/**
 * A `/Link` annotation on a page that points somewhere outside the document.
 *
 * The `url` is the one PDF.js resolved and protocol-checked, never the raw
 * `unsafeUrl` off the annotation: a hostile document can name any scheme it
 * likes, and only PDF.js's own allow-list decides what becomes a real target.
 */
export interface PageLink {
  url: string;
  /** `[x0, y0, x1, y1]` in PDF user space, as the annotation declares it. */
  rect: [number, number, number, number];
}

export interface RenderPageOptions {
  scale: number;
  canvas: HTMLCanvasElement;
  /** Abort an in-flight render (e.g. when the page scrolls out of view). */
  signal?: AbortSignal;
  /**
   * Set when the caller overlays interactive form widgets as DOM inputs (see
   * {@link PdfEngine.renderAnnotationLayer}). Field values are then left out of
   * the canvas, since the inputs already show them and painting both renders
   * the same text twice. Leave unset for standalone rasterisations such as
   * thumbnails, which have no overlay and do need the values painted in.
   */
  overlayForms?: boolean;
  /**
   * Invert the rasterised pixels for dark mode. Done in the canvas (a
   * difference-with-white composite at full backing-store resolution) rather
   * than a CSS filter, which some engines re-rasterise at CSS resolution and
   * blur. The caller re-renders when the theme changes.
   */
  invert?: boolean;
  /**
   * Optional page tint (RGB 0-255) multiplied over the (inverted) page — e.g. a
   * green or amber dark-reading scheme. Multiply keeps black black and colours
   * the ink, preserving anti-aliasing. Only meaningful together with `invert`.
   */
  tint?: [number, number, number];
}

/** Options for the DOM overlay renders (text layer, annotation layer). */
export interface RenderLayerOptions {
  scale: number;
  /**
   * Abort a superseded layer render. Without this a stale pass can interleave
   * its appends with a newer one and leave duplicated elements behind.
   */
  signal?: AbortSignal;
}

/** A rasterised page image (e.g. for OCR): a PNG data URL plus its pixel size. */
export interface PageImage {
  dataUrl: string;
  width: number;
  height: number;
}

/** A text-search hit. */
export interface SearchMatch {
  /** 1-based page number. */
  pageNumber: number;
  /** Character offset of the match within the page's extracted text. */
  index: number;
  /** Surrounding text, for display in the results list. */
  snippet: string;
}
