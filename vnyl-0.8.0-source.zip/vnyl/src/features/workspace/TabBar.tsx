import { useRef } from 'react';

import { Icon } from '@/components/common';
import { openDocumentViaPicker } from '@/state/actions';

import { closeTab, switchTab } from './actions';
import { useWorkspaceStore } from './store';

/**
 * The open-documents strip (shown once two or more PDFs are open). Follows the
 * WAI-ARIA tabs pattern: one tab stop, arrow keys move between tabs, Delete
 * closes the focused one; middle-click closes too.
 */
export function TabBar() {
  const tabs = useWorkspaceStore((s) => s.tabs);
  const activeId = useWorkspaceStore((s) => s.activeId);
  const listRef = useRef<HTMLDivElement>(null);

  if (tabs.length < 2) return null;

  const focusTab = (id: string) =>
    listRef.current?.querySelector<HTMLElement>(`[data-tab-id="${id}"]`)?.focus();

  const onKeyDown = (e: React.KeyboardEvent, index: number) => {
    const move = (to: number) => {
      const target = tabs[(to + tabs.length) % tabs.length];
      focusTab(target.id);
      void switchTab(target.id);
    };
    if (e.key === 'ArrowRight') move(index + 1);
    else if (e.key === 'ArrowLeft') move(index - 1);
    else if (e.key === 'Home') move(0);
    else if (e.key === 'End') move(tabs.length - 1);
    else if (e.key === 'Delete') void closeTab(tabs[index].id);
    else return;
    e.preventDefault();
  };

  return (
    <div className="folio-tabbar">
      <div ref={listRef} className="folio-tabbar__list" role="tablist" aria-label="Open documents">
        {tabs.map((tab, i) => {
          const active = tab.id === activeId;
          return (
            <div key={tab.id} className={`folio-tab${active ? ' is-active' : ''}`}>
              <button
                type="button"
                role="tab"
                data-tab-id={tab.id}
                aria-selected={active}
                tabIndex={active ? 0 : -1}
                className="folio-tab__button"
                title={tab.name}
                onClick={() => void switchTab(tab.id)}
                onAuxClick={(e) => {
                  if (e.button === 1) void closeTab(tab.id);
                }}
                onKeyDown={(e) => onKeyDown(e, i)}
              >
                <Icon name="file" size={14} />
                <span className="folio-tab__name">{tab.name}</span>
                {tab.edited && <span className="folio-tab__dot" aria-label="edited" />}
              </button>
              <button
                type="button"
                className="folio-tab__close"
                aria-label={`Close ${tab.name}`}
                tabIndex={-1}
                onClick={() => void closeTab(tab.id)}
              >
                <Icon name="x" size={12} />
              </button>
            </div>
          );
        })}
      </div>
      <button
        type="button"
        className="folio-icon-button"
        aria-label="Open another document"
        title="Open another document"
        onClick={() => void openDocumentViaPicker()}
      >
        <Icon name="plus" size={16} />
      </button>
    </div>
  );
}
