export { TabBar } from './TabBar';
export { registerWorkspace, switchTab, closeTab, cycleTab } from './actions';
export { registerWorkspaceCommands } from './commands';
export { useWorkspaceStore, neighbourAfterClose, type Tab } from './store';
export { getTabSource } from './tabSource';
