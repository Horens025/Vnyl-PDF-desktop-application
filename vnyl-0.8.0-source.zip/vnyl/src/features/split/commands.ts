import { announce } from '@/a11y/announcer';
import { commandRegistry } from '@/commands';
import { useWorkspaceStore } from '@/features/workspace';
import { useDocumentStore } from '@/state/documentStore';

import { useSplitStore } from './store';

/** Open (or close) split view. Opens on another open document if there is one, else the same one. */
export function toggleSplit(): void {
  const split = useSplitStore.getState();
  if (split.open) {
    split.setOpen(false);
    announce('Split view closed');
    return;
  }
  const { tabs, activeId } = useWorkspaceStore.getState();
  const other = tabs.find((t) => t.id !== activeId) ?? tabs.find((t) => t.id === activeId);
  if (!other) return;
  split.setSource({ kind: 'tab', id: other.id });
  split.setOpen(true);
  announce(
    other.id === activeId
      ? 'Split view open, showing this document'
      : `Split view open, showing ${other.name}`,
  );
}

let registered = false;

export function registerSplitCommands(): void {
  if (registered) return;
  registered = true;
  commandRegistry.register({
    id: 'view.toggleSplit',
    title: 'Toggle split view',
    category: 'View',
    keybinding: 'Mod+Alt+S',
    when: () => useDocumentStore.getState().status === 'ready' || useSplitStore.getState().open,
    run: toggleSplit,
  });
}
