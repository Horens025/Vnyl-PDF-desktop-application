export { SplitArea } from './SplitArea';
export { registerSplitCommands, toggleSplit } from './commands';
export { useSplitStore } from './store';
