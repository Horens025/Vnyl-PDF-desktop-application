export { registerDeepLinks } from './openFromDeepLink';
