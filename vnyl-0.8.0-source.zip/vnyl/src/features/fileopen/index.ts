export { registerFileOpen } from './openFromLaunch';
