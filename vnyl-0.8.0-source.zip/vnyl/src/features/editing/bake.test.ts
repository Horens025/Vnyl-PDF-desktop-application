// @vitest-environment node
import zlib from 'node:zlib';

import { degrees, PDFDocument, StandardFonts } from 'pdf-lib';
import { describe, expect, it, vi } from 'vitest';

import { MissingPageError } from '@/core/pdf/errors';

import { hexToRgb01, standardFontFor, stampEdits, wrapText } from './bake';
import { MARK_GLYPH_PATHS, MARK_GLYPH_STROKE_WIDTH, type EditItem } from './types';

/**
 * Inflate every FlateDecode stream in a PDF and return the concatenated decoded
 * text. pdf-lib compresses content streams, so drawn text only appears after
 * decompression. Lets us assert what was drawn without spinning up a pdf.js worker.
 */
function decodedStreams(bytes: Uint8Array): string {
  const buf = Buffer.from(bytes);
  const stream = Buffer.from('stream');
  const endstream = Buffer.from('endstream');
  let out = '';
  let idx = 0;
  for (;;) {
    const s = buf.indexOf(stream, idx);
    if (s === -1) break;
    let start = s + stream.length;
    if (buf[start] === 0x0d) start++; // CR
    if (buf[start] === 0x0a) start++; // LF
    const e = buf.indexOf(endstream, start);
    if (e === -1) break;
    let end = e;
    if (buf[end - 1] === 0x0a) end--;
    if (buf[end - 1] === 0x0d) end--;
    const chunk = buf.subarray(start, end);
    try {
      out += zlib.inflateSync(chunk).toString('latin1');
    } catch {
      out += chunk.toString('latin1');
    }
    idx = e + endstream.length;
  }
  return out;
}

// A valid 1x1 transparent PNG.
const PNG_1x1 =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

async function onePagePdf(): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  doc.addPage([595, 842]); // A4 in points
  return doc.save();
}

/**
 * A 600x800pt page: round dimensions so the mark tests below (which check
 * exact substrings in the content stream) get exact floats out of stampEdits'
 * `rect fraction -> PDF points` math, not long repeating decimals to fight in
 * the assertions.
 */
async function squarePagePdf(): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  doc.addPage([600, 800]);
  return doc.save();
}

describe('hexToRgb01', () => {
  it('parses #rrggbb into 0..1 components', () => {
    expect(hexToRgb01('#ffffff')).toEqual({ r: 1, g: 1, b: 1 });
    expect(hexToRgb01('#000000')).toEqual({ r: 0, g: 0, b: 0 });
    expect(hexToRgb01('#ff0000')).toEqual({ r: 1, g: 0, b: 0 });
  });

  it('expands #rgb shorthand and falls back to black on junk', () => {
    expect(hexToRgb01('#f00')).toEqual({ r: 1, g: 0, b: 0 });
    expect(hexToRgb01('not-a-color')).toEqual({ r: 0, g: 0, b: 0 });
  });
});

describe('standardFontFor', () => {
  it('maps family + bold to the right StandardFont', () => {
    expect(standardFontFor('Helvetica', false)).toBe(StandardFonts.Helvetica);
    expect(standardFontFor('Helvetica', true)).toBe(StandardFonts.HelveticaBold);
    expect(standardFontFor('Times', false)).toBe(StandardFonts.TimesRoman);
    expect(standardFontFor('Times', true)).toBe(StandardFonts.TimesRomanBold);
    expect(standardFontFor('Courier', true)).toBe(StandardFonts.CourierBold);
  });
});

describe('wrapText', () => {
  it('honors existing newlines', async () => {
    const doc = await PDFDocument.create();
    const font = await doc.embedFont(StandardFonts.Helvetica);
    expect(wrapText('a\nb\nc', font, 12, 1000)).toEqual(['a', 'b', 'c']);
  });

  it('wraps to the given width', async () => {
    const doc = await PDFDocument.create();
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const words = 'one two three four five six seven eight nine ten';
    const lines = wrapText(words, font, 24, 120);
    expect(lines.length).toBeGreaterThan(1);
    // Every wrapped line fits (a lone over-wide word is the only allowed overflow).
    for (const line of lines) {
      if (line.includes(' ')) expect(font.widthOfTextAtSize(line, 24)).toBeLessThanOrEqual(120);
    }
  });
});

describe('stampEdits', () => {
  const textEdit: EditItem = {
    id: 't1',
    kind: 'text',
    pageNumber: 1,
    rect: { x: 0.1, y: 0.1, width: 0.5, height: 0.2 },
    text: 'FOLIOEDITTOKEN',
    fontFamily: 'Helvetica',
    bold: false,
    fontSizePt: 18,
    colorHex: '#112233',
    createdAt: 0,
  };
  const imageEdit: EditItem = {
    id: 'i1',
    kind: 'image',
    pageNumber: 1,
    rect: { x: 0.2, y: 0.5, width: 0.3, height: 0.2 },
    dataUrl: PNG_1x1,
    mime: 'image/png',
    createdAt: 0,
  };
  const markEdit: EditItem = {
    id: 'm1',
    kind: 'mark',
    pageNumber: 1,
    // A 60x60pt square on the 600x800 page from squarePagePdf(): stampEdits
    // turns this into x=100, yTop=700, scale=0.6 exactly (see squarePagePdf's
    // comment), which the assertions below match as literal substrings.
    rect: { x: 100 / 600, y: 100 / 800, width: 60 / 600, height: 60 / 800 },
    glyph: 'check',
    colorHex: '#111111',
    createdAt: 0,
  };

  it('draws text into the page content stream and keeps the PDF valid', async () => {
    const pdf = await PDFDocument.load(await onePagePdf());
    await stampEdits(pdf, [textEdit]);
    const out = await pdf.save();

    // Reloads and preserves the page.
    const reloaded = await PDFDocument.load(out);
    expect(reloaded.getPageCount()).toBe(1);
    // pdf-lib shows text as a hex string operand (<...> Tj) in the Flate content
    // stream; assert the token's hex encoding is present.
    const hex = [...'FOLIOEDITTOKEN']
      .map((c) => c.charCodeAt(0).toString(16).padStart(2, '0'))
      .join('')
      .toUpperCase();
    expect(decodedStreams(out).toUpperCase()).toContain(hex);
  });

  it('adds image data to the document', async () => {
    const textOnly = await PDFDocument.load(await onePagePdf());
    await stampEdits(textOnly, [textEdit]);
    const textBytes = await textOnly.save();

    const withImage = await PDFDocument.load(await onePagePdf());
    await stampEdits(withImage, [textEdit, imageEdit]);
    const imageBytes = await withImage.save();

    expect(imageBytes.length).toBeGreaterThan(textBytes.length);
    expect((await PDFDocument.load(imageBytes)).getPageCount()).toBe(1);
  });

  it('skips empty text', async () => {
    const pdf = await PDFDocument.load(await onePagePdf());
    await stampEdits(pdf, [{ ...textEdit, id: 'blank', text: '   ' }]);
    expect((await pdf.save()).length).toBeGreaterThan(0);
  });

  it('throws rather than dropping an edit placed on a missing page', async () => {
    const pdf = await PDFDocument.load(await onePagePdf());
    await expect(stampEdits(pdf, [{ ...textEdit, id: 'offpage', pageNumber: 99 }])).rejects.toThrow(
      MissingPageError,
    );
    await expect(
      stampEdits(pdf, [{ ...markEdit, id: 'mark-offpage', pageNumber: 99 }]),
    ).rejects.toThrow(MissingPageError);
  });

  it("draws a check mark as a stroked SVG path anchored at the box's top edge", async () => {
    // Pins down the shape this test's operator assertions below assume, so a
    // change to the shared path constant fails here first with a clear signal.
    expect(MARK_GLYPH_PATHS.check).toBe('M 20 55 L 42 76 L 82 24');

    const pdf = await PDFDocument.load(await squarePagePdf());
    await stampEdits(pdf, [markEdit]);
    const stream = decodedStreams(await pdf.save());

    // The raw MARK_GLYPH_PATHS coordinates land in the stream unmodified: no
    // manual y-flip, since drawSvgPath already applies its own (see bake.ts).
    expect(stream).toContain('20 55 m');
    expect(stream).toContain('42 76 l');
    expect(stream).toContain('82 24 l');
    // Scaled by w/100 = 60/100 = 0.6 (y negated: drawSvgPath's own flip).
    expect(stream).toContain('0.6 0 0 -0.6 0 0 cm');
    // Anchored at the box's *top* edge (yTop = 800 - 100 = 700), unlike
    // drawImage above which anchors at the bottom (yTop - h = 640): see the
    // comment in bake.ts for the empirical confirmation of this y-axis.
    expect(stream).toContain('1 0 0 1 100 700 cm');
    expect(stream).not.toContain('100 640 cm');
    // Stroked (not filled) in the item's color, at the shared stroke width.
    const { r } = hexToRgb01(markEdit.colorHex);
    expect(stream).toContain(`${r} ${r} ${r} RG`);
    expect(stream).toContain(`${MARK_GLYPH_STROKE_WIDTH} w`);
  });

  it('draws a cross mark as two crossing stroke segments', async () => {
    expect(MARK_GLYPH_PATHS.cross).toBe('M 22 22 L 78 78 M 78 22 L 22 78');

    const pdf = await PDFDocument.load(await squarePagePdf());
    await stampEdits(pdf, [{ ...markEdit, id: 'm2', glyph: 'cross' }]);
    const stream = decodedStreams(await pdf.save());

    // A cross is two independent moveTo/lineTo segments, both stroked by the
    // same closing `S` (see MARK_GLYPH_PATHS.cross).
    expect(stream).toContain('22 22 m');
    expect(stream).toContain('78 78 l');
    expect(stream).toContain('78 22 m');
    expect(stream).toContain('22 78 l');
  });

  it('places an image and a mark where the user saw them on a 90°-rotated page', async () => {
    // Same fixture pageGeometry.test.ts checks placeRect/offsetInFrame
    // against: a 400x600 MediaBox turned 90 degrees (displayed as 600x400),
    // and a rect a quarter in from the left, half way down, half the
    // displayed width, a quarter of the displayed height. placeRect resolves
    // that to {x: 300, y: 150, width: 300, height: 100, rotate: degrees(90)}.
    const doc = await PDFDocument.create();
    const page = doc.addPage([400, 600]);
    page.setRotation(degrees(90));
    const rect = { x: 0.25, y: 0.5, width: 0.5, height: 0.25 };

    const drawImage = vi.spyOn(page, 'drawImage');
    const drawSvgPath = vi.spyOn(page, 'drawSvgPath');

    await stampEdits(doc, [
      { ...imageEdit, rect },
      { ...markEdit, rect },
    ]);

    expect(drawImage).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ x: 300, y: 150, width: 300, height: 100, rotate: degrees(90) }),
    );
    // The mark is anchored at the box's own top edge: offsetInFrame(placement,
    // 0, height) on this turn sends the box's own "up" 100 units in negative
    // user-x (see offsetInFrame's 90-degree case), landing at x=300-100=200,
    // y unchanged at 150. Scale is still width/100 (=300/100=3): marks are
    // square, so width and height agree.
    expect(drawSvgPath).toHaveBeenCalledWith(
      MARK_GLYPH_PATHS.check,
      expect.objectContaining({ x: 200, y: 150, scale: 3, rotate: degrees(90) }),
    );
  });
});
