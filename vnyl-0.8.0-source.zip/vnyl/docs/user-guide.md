# Vnyl user guide

A quick tour of everyday use. For every shortcut, open **Help > Keyboard shortcuts**
(`Ctrl/Cmd+/`).

## Opening documents

* **Open** with `Ctrl/Cmd+O`, drag a PDF onto the window, or pick one from **Recent** on the
  start screen (desktop). Opening a second PDF adds a **tab**; switch with a click or
  `Ctrl/Cmd+Alt+←/→`, close with the ✕ or a middle-click.
* **Split view** (`Ctrl/Cmd+Alt+S`, or **View > Split view**) shows a second document, or
  another part of the same one, beside or below the first. The link button makes both
  scroll together, which is handy for comparing versions.

## Marking up

* Select text and a small bar appears: **highlight**, **underline**, **strikethrough**,
  **squiggly** or **comment**, in six colours.
* Click any markup to change its colour (or a highlight's strength) or delete it.
* For a lot of marking, open **Annotate > Markup toolbar** (`Ctrl/Cmd+Shift+A`), pick a tool,
  and every passage you select is marked until you press `Esc`.
* Markups are saved into the PDF when you save, so other readers show them too.

## Forms, text, signing, OCR

* Fill form fields directly on the page. **Annotate** and the right-click menu add text,
  images, check marks and notes.
* **Sign > Add signature** places a drawn or typed signature; **Digitally sign** uses a
  certificate and flags later changes.
* **Tools > All tools > OCR** makes a scanned PDF searchable.

## Tools

Open **Tools > All tools** (`Ctrl/Cmd+Shift+K`). Every tool works on any open document, and
the document on screen is used as you see it, with your markups.

| Tool | What it does |
| --- | --- |
| PDF to images | PNG, JPG or WebP at 72, 150 or 300 DPI, for any pages |
| PDF to text | Plain text or Markdown, with a preview |
| Images to PDF | Many pictures into one PDF; reorder them; A4, Letter or fit to image |
| Merge PDFs | Combine PDFs into one |
| Rotate, delete & rearrange | Drag pages into a new order |
| Split PDF | By single pages, every N pages, or ranges such as `1-3, 4-6` |
| Extract pages | Keep chosen pages, in the order you type them |
| Compress | Make photo-heavy PDFs smaller; text stays sharp |
| Compare documents | See what changed between two versions |

Results can be opened as a new tab or saved. On the desktop app, saving uses your system's
Save dialog, and **Save all to folder…** writes many files at once (it asks before replacing
files with the same names).

## Looks

**Appearance** (the sun icon) switches light, dark or match-system; the dark reading colour
(night, green, amber); **Liquid Glass** or **Classic**; and **Frosted** or **Clear** glass.

## Privacy

Your documents are processed on your computer and are never uploaded. The app only goes
online when you ask it to: opening a PDF from a web address, checking for updates in the
desktop app, and the AI assistant, which is off until you turn it on and add your own key
(see [AI & MCP](ai.md)).
